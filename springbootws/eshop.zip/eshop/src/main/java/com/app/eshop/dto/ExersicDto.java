package com.app.eshop.dto;

import lombok.Data;

@Data
public class ExersicDto {
	private Long grantId;
	private Long empId;
	private Double option;
}                                                                              
