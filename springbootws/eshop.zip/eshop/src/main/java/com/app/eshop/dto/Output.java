package com.app.eshop.dto;

import lombok.Data;

@Data
public class Output {
	
	private Long grantId;
	private Double sum;
}
