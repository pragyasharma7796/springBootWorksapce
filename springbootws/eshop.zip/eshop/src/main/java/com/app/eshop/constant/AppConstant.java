package com.app.eshop.constant;

public interface AppConstant {
	public static String EMPLOYEE_TABLE_NAME = "employee_table";
	public static String GRANT_TABLE_NAME = "grant_table";
	public static String PLAN_TABLE_NAME = "plan_table";
	public static String ALLOCATION_TABLE = "allocation_table";
	String ALLOCATION_ACTIVITY_TABLE = "allocation_activity_table";
}
