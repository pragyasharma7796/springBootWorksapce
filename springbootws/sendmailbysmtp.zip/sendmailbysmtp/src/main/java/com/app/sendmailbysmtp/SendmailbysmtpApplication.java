package com.app.sendmailbysmtp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SendmailbysmtpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SendmailbysmtpApplication.class, args);
	}

}
